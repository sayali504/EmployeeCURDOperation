package com.emp.exception;

public class NoEmpFoundException  extends RuntimeException{

	public NoEmpFoundException(String message) {
		
		super(message);
	}
	
	
}
